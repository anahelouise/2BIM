package br.com.biblioteca.projeto.servico;

import br.com.biblioteca.projeto.entidade.Livro;
import br.com.biblioteca.projeto.repositorio.LivroRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class LivroServicoImple implements LivroServico{

    @Autowired
    private LivroRepositorio livroRepositorio;

    @Override
    public Livro postLivro(Livro livro) {
        return livroRepositorio.save(livro);
    }

    @Override
    public List<Livro> getTodosLivros() {
        List<Livro> todosLivros = livroRepositorio.findAll();
        return todosLivros;
    }

    @Override
    public Livro getLivro(Long id) {
        Optional<Livro> livro = livroRepositorio.findById(id);
        if (livro.isPresent()) {
            return livro.get();
        }
        return null;
    }

    @Override
    public Livro putLivro(Long id, Livro livro) {
        Optional<Livro> livroUm = livroRepositorio.findById(id);

        if (livroUm.isPresent()) {
            Livro livroPadrao = livroUm.get();

            if (Objects.nonNull(livro.getGrupo()) && !"".equalsIgnoreCase(livro.getGrupo())) {
                livroPadrao.setGrupo(livro.getGrupo());
            }

            if (Objects.nonNull(livro.getCor()) && !"".equalsIgnoreCase(livro.getCor())) {
                livroPadrao.setCor(livro.getCor());
            }

            if (Objects.nonNull(livro.getCapa()) && !"".equalsIgnoreCase(livro.getCapa())) {
                livroPadrao.setCapa(livro.getCapa());
            }

            if (Objects.nonNull(livro.getNome()) && !"".equalsIgnoreCase(livro.getNome())) {
                livroPadrao.setNome(livro.getNome());
            }

            if (Objects.nonNull(livro.getAutor()) && !"".equalsIgnoreCase(livro.getAutor())) {
                livroPadrao.setAutor(livro.getAutor());
            }

            if (Objects.nonNull(livro.getSinopse()) && !"".equalsIgnoreCase(livro.getSinopse())) {
                livroPadrao.setSinopse(livro.getSinopse());
            }

            if (Objects.nonNull(livro.getAno()) && !"".equalsIgnoreCase(livro.getAno())) {
                livroPadrao.setAno(livro.getAno());
            }
            
            return livroRepositorio.save(livroPadrao);
        }
        return null;
    }

    @Override
    public String deleteLivro(Long id) {
        if (livroRepositorio.findById(id).isPresent()) {
            livroRepositorio.deleteById(id);
            return "Livro removido com sucesso!";
        }
        return "O livro não existe no banco de dados!";
    }
}
