package br.com.biblioteca.projeto.controle;

import br.com.biblioteca.projeto.entidade.Livro;
import br.com.biblioteca.projeto.servico.LivroServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
public class LivroControle {

    @Autowired
    private LivroServico livroServico;

    @PostMapping("/livro")
    public Livro postUsuario(@RequestBody Livro livro) {
        return livroServico.postLivro(livro);
    }

    @GetMapping("/livro")
    public List<Livro> getTodosLivs() {
        return livroServico.getTodosLivros();
    }

    @GetMapping("/livro/{id}")
    public Livro getLivro(@PathVariable("id") Long id) {
        return livroServico.getLivro(id);
    }

    @PutMapping("/livro/{id}")
    public Livro putLivro(@PathVariable("id") Long id, @RequestBody Livro livro) {
        return livroServico.putLivro(id, livro);
    }

    @DeleteMapping("/livro/{id}")
    public String deleteLivro(@PathVariable("id") Long id) {
        return livroServico.deleteLivro(id);
    }
}