package br.com.biblioteca.projeto.controle;

import br.com.biblioteca.projeto.entidade.Usuario;
import br.com.biblioteca.projeto.servico.UsuarioServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin("*")
@RestController
public class UsuarioControle {

    @Autowired
    private UsuarioServico usuarioServico;

    @PostMapping("/usuario")
    public Usuario postUsuario(@RequestBody Usuario usuario) {
        return usuarioServico.postUsuario(usuario);
    }

    @GetMapping("/usuario")
    public List<Usuario> getTodosUsuarios() {
        return usuarioServico.getTodosUsuarios();
    }

    @GetMapping("/usuario/{id}")
    public Usuario getUsuario(@PathVariable("id") Long id) {
        return usuarioServico.getUsuario(id);
    }

    @PostMapping("/usuario/auth/{id}")
    public ResponseEntity<?> autenticarUsuario(@PathVariable("id") Long id, @RequestBody Map<String, String> requestBody) {
        String senha = requestBody.get("senha");

        Usuario usuario = usuarioServico.getUsuario(id);

        if (usuario != null && usuario.getSenha().equals(senha)) {
            return ResponseEntity.ok().body(usuario);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Credenciais incorretas");
        }
    }

    @PutMapping("/usuario/{id}")
    public Usuario putUsuario(@PathVariable("id") Long id, @RequestBody Usuario usuario) {
        return usuarioServico.putUsuario(id, usuario);
    }

    @DeleteMapping("/usuario/{id}")
    public String deleteUsuario(@PathVariable("id") Long id) {
        return usuarioServico.deleteUsuario(id);
    }
}