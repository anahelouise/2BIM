package br.com.biblioteca.projeto.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import br.com.biblioteca.projeto.entidade.Livro;

public interface LivroRepositorio extends JpaRepository<Livro, Long>{
    
}