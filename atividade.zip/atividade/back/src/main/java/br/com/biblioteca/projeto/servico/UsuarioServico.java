package br.com.biblioteca.projeto.servico;

import java.util.List;

import br.com.biblioteca.projeto.entidade.Usuario;

public interface UsuarioServico {
    
    Usuario postUsuario(Usuario usuario);

    List<Usuario> getTodosUsuarios();

    Usuario getUsuario(Long id);

    Usuario putUsuario(Long id, Usuario usuario);

    String deleteUsuario(Long id);

}
