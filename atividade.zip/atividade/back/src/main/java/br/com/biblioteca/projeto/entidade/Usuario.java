package br.com.biblioteca.projeto.entidade;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Usuario {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private String nome;
    @Column(nullable = false)
    private String senha;

    public Usuario() {

    }
    
    public Usuario(Long id, String nome, String senha) {
        this.id = id;
        this.nome = nome;
        this.senha = senha;
    }

    // Getter para id
    public Long getId() {
        return id;
    }
    
    // Setter para id
    public void setId(Long id) {
        this.id = id;
    }
    
    // Getter para nome
    public String getNome() {
        return nome;
    }
    
    // Setter para nome
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    // Getter para senha
    public String getSenha() {
        return senha;
    }
    
    // Setter para senha
    public void setSenha(String senha) {
        this.senha = senha;
    }

}
