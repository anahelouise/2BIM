package br.com.biblioteca.projeto.entidade;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Livro {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private String grupo;
    @Column(nullable = false)
    private String cor;
    @Column(nullable = false)
    private String capa;
    @Column(nullable = false)
    private String nome;
    @Column(nullable = false)
    private String autor;
    @Column(nullable = false)
    private String sinopse;
    @Column(nullable = false)
    private String ano;

    public Livro() {

    }
    
    public Livro(Long id, String grupo, String cor, String capa, String nome, String autor, String sinopse, String ano) {
        this.id = id;
        this.grupo = grupo;
        this.cor = cor;
        this.capa = capa;
        this.nome = nome;
        this.autor = autor;
        this.sinopse = sinopse;
        this.ano = ano;
    }

    // Getters e setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getCapa() {
        return capa;
    }

    public void setCapa(String capa) {
        this.capa = capa;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getSinopse() {
        return sinopse;
    }

    public void setSinopse(String sinopse) {
        this.sinopse = sinopse;
    }

    public String getAno() {
        return ano;
    }

    public void setAno(String ano) {
        this.ano = ano;
    }

}
