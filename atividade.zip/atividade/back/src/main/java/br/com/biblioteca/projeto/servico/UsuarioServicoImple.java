package br.com.biblioteca.projeto.servico;

import br.com.biblioteca.projeto.entidade.Usuario;
import br.com.biblioteca.projeto.repositorio.UsuarioRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class UsuarioServicoImple implements UsuarioServico{

    @Autowired
    private UsuarioRepositorio usuarioRepositorio;

    @Override
    public Usuario postUsuario(Usuario usuario) {
        return usuarioRepositorio.save(usuario);
    }

    @Override
    public List<Usuario> getTodosUsuarios() {
        List<Usuario> todosUsuarios = usuarioRepositorio.findAll();
        return todosUsuarios;
    }

    @Override
    public Usuario getUsuario(Long id) {
        Optional<Usuario> usuario = usuarioRepositorio.findById(id);
        if (usuario.isPresent()) {
            return usuario.get();
        }
        return null;
    }

    @Override
    public Usuario putUsuario(Long id, Usuario usuario) {
        Optional<Usuario> usuarioUm = usuarioRepositorio.findById(id);

        if (usuarioUm.isPresent()) {
            Usuario usuarioPadrao = usuarioUm.get();

            if (Objects.nonNull(usuario.getNome()) && !"".equalsIgnoreCase(usuario.getNome())) {
                usuarioPadrao.setNome(usuario.getNome());
            }
            if (Objects.nonNull(usuario.getSenha()) && !"".equalsIgnoreCase(usuario.getSenha())) {
                usuarioPadrao.setSenha(usuario.getSenha());
            }
            return usuarioRepositorio.save(usuarioPadrao);
        }
        return null;
    }

    @Override
    public String deleteUsuario(Long id) {
        if (usuarioRepositorio.findById(id).isPresent()) {
            usuarioRepositorio.deleteById(id);
            return "Usuário removido com sucesso!";
        }
        return "O usuário não existe no banco de dados!";
    }
}
