package br.com.biblioteca.projeto.servico;

import java.util.List;

import br.com.biblioteca.projeto.entidade.Livro;

public interface LivroServico {
    
    Livro postLivro(Livro livro);

    List<Livro> getTodosLivros();

    Livro getLivro(Long id);

    Livro putLivro(Long id, Livro livro);

    String deleteLivro(Long id);

}
