function fazerLogin() {
    let idString = document.getElementById("nome").value;
    let id = parseInt(idString);
    let senha = document.getElementById("senha").value;

    fetch(`http://localhost:8080/usuario/${id}`, {
        method: "GET",
        headers: {
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`Erro na requisição: ${response.statusText}`);
        }
        return response.json();
    })
    .then(data => {
        // Verificar se o usuário com ID correspondente existe e a senha está correta
        if (data && data.senha === senha) {
            // Redirecionar usuário se existir e a senha estiver correta
            //redirecionarUsuario();
            if (id === 1) {
                window.location.href = "../Bibliotecario/Bibliotecario.html";
            } else if (id === 2) {
                window.location.href = "../Pendente/pendente.html";
            } else {
                window.location.href = "../Acesso/index.html";
            }
        } else {
            alert("Usuário não encontrado ou senha incorreta");
        }
    })
    .catch(error => {
        console.error("Erro na requisição:", error);
        alert("Usuário não encontrado ou senha incorreta");
    });

    // Evita o envio do formulário padrão
    return false;
}

