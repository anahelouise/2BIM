function login() {
    window.location.href = "../login/index.html";
    return false;
    console.log()
}

function adicionarLivros() {
    window.location.href = "../adicionar-livros/adicionar-livros.html";
    return false
}

function gerenciarLivros() {
    window.location.href = "../gerenciar-livros/gerenciar-livros.html"
    return false
}