let titulo = document.getElementById('titulo');
let autor = document.getElementById('autor');
let descricao = document.getElementById('descricao');
let capa = document.getElementById('capa');
let enviar = document.getElementById('enviar');
let grupoDeLivros ;
let modo = "criar";
let temporario;  // variável temporária para armazenar o id dos livros

// salva as informações no ambiente local
if (localStorage.grupoDeLivros != null) {
    grupoDeLivros = JSON.parse(localStorage.getItem('grupoDeLivros'));

} else {
     grupoDeLivros = [];

}

enviar.addEventListener('click', function (e) {
    if(modo === "criar") {

        let objetoLivro = {
            titulo: titulo.value,
            autor: autor.value,
            descricao: descricao.value,
            capa: capa.value
        }

        grupoDeLivros.push(objetoLivro);
        localStorage.setItem('grupoDeLivros', JSON.stringify(grupoDeLivros));
        console.log(grupoDeLivros);
        exibirDados();
        limparTexto();

    } else {
        enviar.textContent = "Atualizar";
        AtualizarLivro(temporario);  // here we replace id with temporario var because id is local variable
        exibirDados(); // 
        enviar.textContent = "Criar";
        modo = "criar";

    }

    e.preventDefault();

});

function exibirDados() {
    let tabela = '';
    for (let i = 0; i < grupoDeLivros.length; i++) {
        tabela += `
        <tr>
            <th scope="row">${i}</th>
            <td>${grupoDeLivros[i].titulo}</td>
            <td>${grupoDeLivros[i].autor}</td>
            <td>${grupoDeLivros[i].descricao}</td>
            <td>${grupoDeLivros[i].capa}</td>
            <td>
                <button class="btn btn-warning" onclick="AtualizarLivro(${i})">Editar</button>
                <button class="btn btn-danger" onclick="DeletarLivro(${i})">Remover</button>
            </td>
        </tr>
        `
        document.getElementById('tbody').innerHTML = tabela;
    }    

}

function limparTexto() {
    titulo.value = "";
    autor.value = "";
    descricao.value = "";
    capa.value = "";

}

// para deletar um livro, ele deve ser identificado
function DeletarLivro(id) {
    grupoDeLivros.splice(id, 1); // deletando 
    localStorage.setItem('grupoDeLivros', JSON.stringify(grupoDeLivros)); // atualiza o armazenamento local
    exibirDados(); // exibe as informações após deletar

}


function AtualizarLivro(id) {
    temporario = id;
    modo = "update";
    enviar.textContent = "Atualizar";
    // para modificar um livro, ele deve ser identificado

    let objetoLivro = {
        titulo: titulo.value,
        autor: autor.value,
        descricao: descricao.value,
        capa: capa.value
    }

    titulo.value = grupoDeLivros[id].titulo;
    autor.value = grupoDeLivros[id].autor;
    descricao.value = grupoDeLivros[id].descricao;
    capa.value = grupoDeLivros[id].capa;

    grupoDeLivros[temporario] = objetoLivro;
    localStorage.setItem('grupoDeLivros', JSON.stringify(grupoDeLivros));
}

exibirDados();