function fazerAtualizar() {
    let idString = document.getElementById("nome").value;
    let id = parseInt(idString);
    let senha = document.getElementById("senha").value;
    let novaSenha = document.getElementById("novaSenha").value;

    fetch(`http://localhost:8080/usuario/${id}`, {
        method: "GET",
        headers: {
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`Erro na requisição: ${response.statusText}`);
        }
        return response.json();
    })
    .then(data => {
        // Verificar se o usuário com ID correspondente existe e a senha está correta
        if (data && data.senha === senha) {
            // Atualizar a senha se existir e a senha estiver correta
            return fetch(`http://localhost:8080/usuario/${id}`, {
                method: "PUT",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ senha: novaSenha })
            });
        } else {
            alert("Usuário não encontrado ou senha incorreta");
        }
    })
    .then(response => {
        if (response && response.ok) {
            alert("Senha atualizada com sucesso");
            redirecionarUsuario(id);
        } else {
            alert("Erro ao atualizar a senha");
        }
    })
    .catch(error => {
        console.error("Erro na requisição:", error);
        alert("Erro na autenticação. Tente novamente mais tarde.");
    });

    // Evita o envio do formulário padrão
    return false;
}

function redirecionarUsuario(id) {
    // Redirecionar para a página apropriada com base no ID
    if (id === 1) {
        window.location.href = "../Bibliotecario/Bibliotecario.html";
    } else if (id === 2) {
        window.location.href = "../Pendente/pendente.html";
    } else {
        window.location.href = "../Acesso/index.html";
    }
}
