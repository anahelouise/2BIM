function adicionarLivros() {
    var nomeLivro = document.getElementById("nomeLivro").value
    var autor = document.getElementById("autor").value
    console.log(autor)
    
    alert("Livro adicionado com sucesso")
    
    }