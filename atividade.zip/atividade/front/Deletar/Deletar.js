function fazerDeletar() {
    let idString = document.getElementById("nome").value;
    let id = parseInt(idString);
    let senha = document.getElementById("senha").value;

    // Fazer a requisição GET para verificar as credenciais no banco de dados
    fetch(`http://localhost:8080/usuario/${id}`, {
        method: "GET",
        headers: {
            "Accept": "application/json",
            "Content-Type": "application/json"
        },
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`Erro na requisição: ${response.statusText}`);
        }
        return response.json();
    })
    .then(data => {
        // Verificar se o usuário com ID correspondente existe e a senha está correta
        if (data && data.senha === senha) {
            // Deletar o usuário se existir e a senha estiver correta
            return fetch(`http://localhost:8080/usuario/${id}`, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json"
                }
            });
        } else {
            alert("Usuário não encontrado ou senha incorreta");
        }
    })
    .then(response => {
        if (response && response.ok) {
            alert("Usuário deletado com sucesso");
        } else {
            alert("Erro ao deletar o usuário");
        }
    })
    .catch(error => {
        console.error("Erro na requisição:", error);
        alert("Erro na autenticação. Tente novamente mais tarde.");
    });

    // Evita o envio do formulário padrão
    return false;
}